clc
clear all

syms x real
f = input('Enter the function f(x): ');
fx = diff(f, x);
fxx = diff(fx, x);

c = solve(fx);
c = double(c);

for i = 1:length(c)
    T1 = subs(fxx, x, c(i));
    T1 = double(T1);
    T3 = subs(f, x, c(i));
    T3 = double(T3);
    
    if (T1 == 0)
        fprintf('The inflection point is x = %d\n', c(i));
    else
        if (T1 < 0)
            fprintf('The maximum point x is %d\n', c(i));
            fprintf('The maximum value of the function is %d\n', T3);
        else
            fprintf('The minimum point x is %d\n', c(i));
            fprintf('The minimum value of the function is %d\n', T3);
        end
    end
    
    cmin = min(c);
    cmax = max(c);
    D = [cmin - 2, cmax + 2];
    ezplot(f, D);
    hold on;
    plot(c(i), T3, 'g*', 'markersize', 15);
end
