clc
clear

syms t x y
f = input('Enter the f vector as i and j order in vector form:');
rbar = input('Enter the r vector as i and j order in vector form:');
lim = input('Enter the limit of integration:');
vecfi = input('Enter the vector field range:');
drbar = diff(rbar, t);
sub = subs(f, [x, y], rbar);
f1 = dot(sub, drbar);
result = int(f1, t, lim(1), lim(2));
disp('Result of the line integral:');
disp(result);
P = inline(vectorize(f(1)), 'x', 'y');
Q = inline(vectorize(f(2)), 'x', 'y');
x = linspace(vecfi(1), vecfi(2), 10);
y = x;
[X, Y] = meshgrid(x, y);
U = P(X, Y);
V = Q(X, Y);
quiver(X, Y, U, V)
hold on
fplot(rbar(1), rbar(2), [lim(1), lim(2)])
axis on
xlabel('x')
ylabel('y')
